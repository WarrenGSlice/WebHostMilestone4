<?php 
	session_start();

	// connect to database
	$conn = mysqli_connect("trial10-mysqldbserver.mysql.database.azure.com", "Warren", "Techn9ne", "complete-blog-php");

	if (!$conn) {
		die("Error connecting to database: " . mysqli_connect_error());
	}
    // define global constants

	define ('ROOT_PATH', realpath(dirname(__FILE__)));
	define('BASE_URL', 'https://trial10.azurewebsites.net/myapp/');
?>